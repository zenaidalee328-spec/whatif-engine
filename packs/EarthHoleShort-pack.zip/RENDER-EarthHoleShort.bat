@echo off
setlocal
cd /d "%~dp0"
title Render EarthHoleShort
echo ==== What If engine: rendering EarthHoleShort ====

where node >nul 2>nul || (echo [X] Node.js not found. Install the LTS version from https://nodejs.org and run this again. & pause & exit /b 1)

if not exist node_modules (
  echo [1/2] Installing packages, first time only...
  call npm i || goto :fail
) else echo [1/2] Packages already installed.

echo [2/2] Rendering video...
if not exist out mkdir out
call npx remotion render src/index.ts EarthHoleShort out\EarthHoleShort.mp4 --gl=angle %* || goto :fail

echo.
echo DONE: out\EarthHoleShort.mp4
start "" "%~dp0out"
pause
exit /b 0

:fail
echo.
echo [X] Something failed. Copy the error above and send it to Claude.
pause
exit /b 1
